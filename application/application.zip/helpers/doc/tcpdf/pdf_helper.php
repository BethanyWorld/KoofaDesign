<?php
function tcpdf()
{
    require_once('tcpdf.php');
}