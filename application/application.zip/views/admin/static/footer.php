<?php
$_URL = base_url();
$_DIR = base_url('assets/ui/');
?>
</div>
<!-- container-fluid -->
<script type="text/javascript" src="<?php echo base_url('assets/ui/js/bootstrap.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/ui/js/bootstrap-select.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/ui/js/script.js'); ?>"></script>

</body>
</html>