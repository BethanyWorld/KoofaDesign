<style>

    .cat-0{
        border: 2px solid #b33333;
        margin: 4px;
        display: inline-block;
    }
</style>