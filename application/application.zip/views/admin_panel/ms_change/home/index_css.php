<style>
    .bootstrap-select > .dropdown-toggle {
        width: 100%;
        padding-left: 25px;
        padding-right: 0;
        z-index: 1;
    }
</style>