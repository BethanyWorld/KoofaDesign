<style>
.cart-product-main-div{
    border: 3px solid #000;
    padding: 10px;
    margin-bottom: 20px !important;
}
.cart-product-main-div table{
    margin: 0 0 0 0 !important;
}
.cart-product-title-div div{
    padding: 0;
    border: 1px solid #ccc;
    padding: 6px;
    margin: 8px;
}
</style>