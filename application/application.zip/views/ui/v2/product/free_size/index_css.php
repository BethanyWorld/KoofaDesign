<style>
    .cropper-container img {
        height: auto !important;
    }
</style>