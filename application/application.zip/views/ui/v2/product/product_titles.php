
<div class="col-xs-12 product-detail-title">
    <h1><?php echo $data['ProductTitle']; ?></h1>
</div>
<div class="col-xs-12 product-code">
        <span>کد محصول:</span>
        <span><?php echo $data['ProductSubTitle']; ?></span>
</div>
<div class="col-xs-12 product-brief">
    <p><?php echo $data['ProductBrief']; ?></p>
</div>