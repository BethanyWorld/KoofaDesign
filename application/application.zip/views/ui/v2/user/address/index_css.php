<style>
    .profile-form-div input ,
    .profile-form-div select {
        width: calc(100% - 145px) !important;
    }

</style>