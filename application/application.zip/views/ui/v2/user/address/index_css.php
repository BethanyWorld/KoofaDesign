<style>
    .profile-form-div input {
        width: calc(100% - 145px) !important;
    }

</style>