<div class="row col-xs-12">

    <div class="container" style="margin-top: 80px;margin-bottom: 60px;">
        <h4 class="text-justify rtl alert <?php echo $class; ?>">
            <i class="fa fa-info hidden" style="
      display: block;
    width: 100%;
    margin-bottom: 14px;
    font-size: 38px;"></i>
            <?php echo $message; ?>
        </h4>
    </div>
</div>