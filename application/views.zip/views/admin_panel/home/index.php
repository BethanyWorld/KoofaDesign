<?php $_DIR = base_url('assets/empanel/'); ?>
<section class="content">
    <div class="container-fluid">
        <div class="block-header">
            <h2>پیشخوان</h2>
        </div>
        <!-- Widgets -->
        <div class="row clearfix">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="info-box bg-pink hover-expand-effect">
                    <div class="icon">
                        <i class="material-icons">playlist_add_check</i>
                    </div>
                    <div class="content">
                        <div class="text">سفارش ناموفق</div>
                        <div class="number count-to">
                            <?php echo $orderTypeCount[1][0]['FailedOrderCount']; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="info-box bg-cyan hover-expand-effect">
                    <div class="icon">
                        <i class="material-icons">help</i>
                    </div>
                    <div class="content">
                        <div class="text">سفارش در انتظار</div>
                        <div class="number count-to">
                            <?php echo $orderTypeCount[0][0]['PendOrderCount']; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="info-box bg-light-green hover-expand-effect">
                    <div class="icon">
                        <i class="material-icons">forum</i>
                    </div>
                    <div class="content">
                        <div class="text">سفارش موفق</div>
                        <div class="number count-to">
                            <?php echo $orderTypeCount[2][0]['SuccessOrderCount']; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="info-box bg-orange hover-expand-effect">
                    <div class="icon">
                        <i class="material-icons">person_add</i>
                    </div>
                    <div class="content">
                        <div class="text">تعدا کاربران</div>
                        <div class="number count-to">
                            <?php echo $usersCount; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
