<style>
    .modal-backdrop.fade {
        z-index: -100 !important;
        display: none !important;
    }
</style>