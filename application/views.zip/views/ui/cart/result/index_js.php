<script type="text/javascript">
    $(document).ready(function () {
        setTimeout(function(){
            window.location.href = base_url + 'User/Home';
        } , 5000);
    });
</script>