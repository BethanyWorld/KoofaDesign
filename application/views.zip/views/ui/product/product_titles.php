<div class="col-md-12 col-xs-12 padding-right product-detail-title">
    <h1><?php echo $data['ProductTitle']; ?></h1>
</div>
<div class="col-md-12 col-xs-12 product-detail-print padding-right">
    <p style="margin:0;"><?php echo $data['ProductBrief']; ?></p>
</div>
<div class="col-md-12 col-xs-12 product-detail-print padding-right product-sub-title">
    <p style="margin: 0;font-size: 16px;color: #000;">
        <span>کد محصول:</span>
        <span><?php echo $data['ProductSubTitle']; ?></span>
    </p>
</div>
