<style>
    @media screen and (max-width: 768px) {


        .main-slider .owl-dot {

        }
        .owl-nav{
            display: none;
        }
        .main-slider .item-slide {
            background-position: center !important;
            background-size: cover !important;
            background-repeat: no-repeat !important;
        }
        .main-slider .owl-dots .owl-dot {
            border-left: 2px solid rgba(0,0,0,0) !important;
            border-right: 2px solid rgba(0,0,0,0) !important;
            width: 15px !important;
            top: 0 !important;
        }
        .slogans span {
            display: inline-block;
            padding: 20px 10px;
            border-right: 1px solid #ccc;
            display: inline-block;
            width: 100%;
            text-align: right;
        }
        .product-slider .info {
            text-align: center;
            padding: 30px 0;
        }
    }
</style>
